from setuptools import setup

setup(
    name="paquete",
    version="0.1",
    description="Este es un paquete de ejemplo",
    author="Gonzalo Muñoz",
    author_email = "gonzalo.munoz@zeke.cl",
    url="http://google.cl",
    #scripts=['script.py'] En caso de querer scripts 
    packages=["paquete","paquete.adios","paquete.hola"] #Declaracion de paquetes incluidos
)

