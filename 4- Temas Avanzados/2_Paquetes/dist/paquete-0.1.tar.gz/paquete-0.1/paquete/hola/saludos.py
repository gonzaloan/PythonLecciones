def saludar():
    print("Este llamada es para testear la importación desde otro archivo.")

class Saludo():
    def __init__(self):
        print("Llamada desde el init de la clase Saludo")