def despedirse():
    print("Este llamada es para testear la importación desde otro archivo Despedida.")

class Despedida():
    def __init__(self):
        print("Llamada desde el init de la clase Despedida")